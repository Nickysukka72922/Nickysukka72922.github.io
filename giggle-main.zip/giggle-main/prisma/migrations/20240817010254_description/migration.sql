-- AlterTable
ALTER TABLE "Site" ADD COLUMN     "description" TEXT NOT NULL DEFAULT 'No description provided';
