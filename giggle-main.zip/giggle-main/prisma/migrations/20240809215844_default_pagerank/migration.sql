-- AlterTable
ALTER TABLE "Site" ALTER COLUMN "pageRank" SET DEFAULT 0;
