-- AlterTable
ALTER TABLE "Site" ADD COLUMN     "order" SERIAL NOT NULL;
