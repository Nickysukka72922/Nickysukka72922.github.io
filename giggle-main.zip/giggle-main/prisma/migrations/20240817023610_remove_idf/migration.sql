/*
  Warnings:

  - You are about to drop the column `IDF` on the `Term` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Term" DROP COLUMN "IDF";
