-- CreateIndex
CREATE INDEX "TermsOnSites_termId_idx" ON "TermsOnSites"("termId");
